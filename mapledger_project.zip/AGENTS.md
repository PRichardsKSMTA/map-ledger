# Tests

**Purpose**    
Jest and React Testing Library suites.

## Key Exports
| Name | Type | Description |
|------|------|-------------|
| MappingAllocationWizard.test | test | Example component test |

## Runbook Cross-References
§3 System Architecture

## TODO (owner: @unassigned)
1. Maintain Jest coverage ≥80% across frontend
2. Keep auth flow integration tests up to date
