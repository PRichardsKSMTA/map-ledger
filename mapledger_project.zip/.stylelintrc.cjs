module.exports = { extends: ["stylelint-config-tailwindcss"] };
