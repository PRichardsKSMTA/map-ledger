import { useState } from 'react';

export interface AccountRow {
  entity: string;
  accountId: string;
  description: string;
  netChange: number;
  glMonth?: string;
  [key: string]: any;
}

interface ExcludeAccountsProps {
  rows: AccountRow[];
  onConfirm: (included: AccountRow[], excluded: AccountRow[]) => void;
}

export default function ExcludeAccounts({ rows, onConfirm }: ExcludeAccountsProps) {
  // Track excluded rows by their index to avoid issues with duplicate or
  // missing account IDs. Using an index based key ensures each row can be
  // toggled independently without React key warnings.
  const [excludedIds, setExcludedIds] = useState<Set<number>>(new Set());

  const toggleExclude = (id: number) => {
    setExcludedIds(prev => {
      const updated = new Set(prev);
      if (updated.has(id)) {
        updated.delete(id);
      } else {
        updated.add(id);
      }
      return updated;
    });
  };

  const included = rows.filter((_, idx) => !excludedIds.has(idx));
  const excluded = rows.filter((_, idx) => excludedIds.has(idx));

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Review and Exclude Accounts</h2>
      <p className="text-sm text-gray-600">Check any accounts you want excluded in mapping.</p>

      <table className="min-w-full text-sm border">
        <thead>
          <tr className="bg-gray-50 text-left">
            <th className="p-2">Exclude</th>
            <th className="p-2">Entity</th>
            <th className="p-2">Account ID</th>
            <th className="p-2">Description</th>
            <th className="p-2 text-right">Net Change</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => (
            <tr key={`${row.accountId}-${idx}`} className="border-t hover:bg-gray-50">
              <td className="p-2">
                <input
                  type="checkbox"
                  checked={excludedIds.has(idx)}
                  onChange={() => toggleExclude(idx)}
                />
              </td>
              <td className="p-2">{row.entity}</td>
              <td className="p-2">{row.accountId}</td>
              <td className="p-2">{row.description}</td>
              <td className="p-2 text-right">{row.netChange.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-between">
        <div className="text-sm text-gray-600">
          Included: {included.length} • Excluded: {excluded.length}
        </div>
        <button
          onClick={() => onConfirm(included, excluded)}
          className="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
        >
          Confirm Exclusions
        </button>
      </div>
    </div>
  );
}
